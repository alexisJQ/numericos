function [x, error,iteraciones,operaciones] = newtonMulti(listaFunciones, puntosIniciales, tol, numeroIteraciones)
    syms x y z
    x= [];
    error = [];
    e=1;
    i=0;
    var = {'x', 'y', 'z'};
    jb = jacobian(listaFunciones);
    while i < numeroIteraciones && e > tol     
        jeval = subs(jb, var, puntosIniciales');
        feval = subs(listaFunciones, var, puntosIniciales');
        jacoInv = inv(jeval);
        xa = puntosIniciales - jacoInv*feval';
        x = [x , xa];
        e = norm(xa - puntosIniciales, inf)/norm(xa, inf);
        error = [error , e];
        puntosIniciales = xa;
        i=i+1
    end
end