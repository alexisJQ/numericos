syms x
f1 = x - 2^(-x);
g1 = 2^(-x); %para funcion constractiva

f2 = exp(-x)-x^2+ 3*x - 2;
g2= (x^2 - exp(-x) +2)/3; %para funcion constractiva

f3= x^3 - 7*x^2 +14*sin(2*pi*x)-6;
g3= (x^3 - +14*sin(2*pi*x)-6)/7*x; %para funcion constractiva
g4= x^3 - 7*x^2 +14*sin(2*pi*x)-6 + x ;
g5=(asin(x^3-7*x^2-6)/14)/2*pi;
%analisis de graficos f1
%analisaremos entre los puntos -2 a 2 porque es donde se puede observar un
%cambio de signo en f1(x)

a=-1;
b=2;

%usaremos una toleracia de 0.0001
tol= 0.00000000001;
tCom=tic;
[x1,error1,iteracion1,operaciones1]=biseccion(a,b,tol,f1);
tFin1=toc(tCom);
tCom=tic;
[x2,error2,iteracion2,operaciones2]=regulaFalsi(a,b,tol,f1);
tFin2=toc(tCom);
tCom=tic;
[x3,error3,iteracion3,operaciones3]=secante(a,b,tol,f1);
tFin3=toc(tCom);
tCom=tic;

[x4,error4,iteracion4,operaciones4]=puntoFijo(a,tol,f1,g1);
tFin4=toc(tCom);
tCom=tic;
[x5,error5,iteracion5,operaciones5]=newtonRp(a,tol,f1);
tFin5=toc(tCom);


figure(1)
hold on
title("Errores de los distintos metodos en x - 2.^(-x) ")
plot(error1)
plot(error2)
plot(error3)
plot(error4)
plot(error5)
legend(["Error metodo biseccion","Error metodo regula false", "Error metodo secante ", "Error metodo punto fijo","Error metodo Newton"],'location','northeast')
hold off
fprintf("Metodos , sus tiempos y cantidad de calculos f1(x)\n");
fprintf("Metodo de la biseccion\nN° de iteraciones:%i\nTiempo:%i\n",iteracion1,tFin1)
fprintf("Metodo regula falsi\nN° de iteraciones:%i\nTiempo:%i\n",iteracion2,tFin2)
fprintf("Metodo de la secante\nN° de iteraciones:%i\nTiempo:%i\n",iteracion3,tFin3)
fprintf("Metodo del punto fijo\nN° de iteraciones:%i\nTiempo:%i\n",iteracion4,tFin4)
fprintf("Metodo de Newton Raphson\nN° de iteraciones:%i\nTiempo:%i\n",iteracion5,tFin5)
%-----------------------------------------------------------------------------------------
figure(2)
hold on
title("Valores de x de los distintos metodos en x - 2.^(-x) ")
plot(x1)
plot(x2)
plot(x3)
plot(x4)
plot(x5)
legend(["Valores x metodo biseccion","Valores x metodo regula false", "Valores x metodo secante ", "Valores x metodo punto fijo","Valores x metodo Newton"],'location','northeast')
hold off

figure(3)

y=[iteracion1 iteracion2 iteracion3 iteracion4 iteracion5];
barh(y,'FaceColor','flat')
yticklabels({'N° Iteracioes biseccion','N° Iteraciones regula Falsi','N° Iteraciones secante','N° Iteraciones punto fijo','N° Iteraciones Newton'})

figure(4)

y=[operaciones1 operaciones2 operaciones3 operaciones4 operaciones5];
barh(y,'FaceColor','flat')
yticklabels({'N° operaciones biseccion','N° operaciones regula Falsi','N° operaciones secante','N° operaciones punto fijo','N° operaciones Newton'})

figure(5)

y=[tFin1 tFin2 tFin3 tFin4 tFin5];
barh(y,'FaceColor','flat')
yticklabels({'Demora biseccion','Demora regula Falsi','Demora secante','Demora punto fijo','Demora Newton'})

pause(10);
% analizaremos f2()
% analisaremos entre los puntos 0 a 1 porque es donde se puede observar un
% cambio de signo en f2(x)
a=0;
b=1;
tCom=tic;   
[x6,error6,iteracion6,operaciones6]=biseccion(a,b,tol,f2);
tFin6=toc(tCom);
tCom=tic;
[x7,error7,iteracion7,operaciones7]=regulaFalsi(a,b,tol,f2);
tFin7=toc(tCom);
tCom=tic;
[x8,error8,iteracion8,operaciones8]=secante(a,b,tol,f2);
tFin8=toc(tCom);
tCom=tic;
[x9,error9,iteracion9,operaciones9]=puntoFijo(a,tol,f2,g2);
tFin9=toc(tCom);
tCom=tic;
[x10,error10,iteracion10,operaciones10]=newtonRp(a,tol,f2);
tFin10=toc(tCom);
figure(6)
hold on
title("Errores de los distintos metodos en exp(-x)-x^2+ 3*x - 2 ")
plot(error6)
plot(error7)
plot(error8)
plot(error9)
plot(error10)
legend(["Error metodo biseccion","Error metodo regula false", "Error metodo secante ", "Error metodo punto fijo","Error metodo Newton"],'location','northeast')
hold off
fprintf("Metodos , sus tiempos y cantidad de calculos f2(x)\n");
fprintf("Metodo de la biseccion\nN° de iteraciones:%i\nTiempo:%i\n",iteracion6,tFin6)
fprintf("Metodo regula falsi\nN° de iteraciones:%i\nTiempo:%i\n",iteracion7,tFin7)
fprintf("Metodo de la secante\nN° de iteraciones:%i\nTiempo:%i\n",iteracion8,tFin8)
fprintf("Metodo del punto fijo\nN° de iteraciones:%i\nTiempo:%i\n",iteracion9,tFin9)
fprintf("Metodo de Newton Raphson\nN° de iteraciones:%i\nTiempo:%i\n",iteracion10,tFin10)

%-----------------------------------------------------------------------------------------
figure(7)
hold on
title("Valores de x en los distintos metodos en exp(-x)-x^2+ 3*x - 2 ")
plot(x6)
plot(x7)
plot(x8)
plot(x9)
plot(x10)
legend(["Valores x metodo biseccion","Valores x metodo regula false", "Valores x metodo secante ", "Valores x metodo punto fijo","Valores x metodo Newton"],'location','northeast')
hold off

figure(8)
y=[iteracion6 iteracion7 iteracion8 iteracion9 iteracion10];
barh(y,'FaceColor','flat')
yticklabels({'N° Iteracioes biseccion','N° Iteraciones regula Falsi','N° Iteraciones secante','N° Iteraciones punto fijo','N° Iteraciones Newton'})

figure(9)

y=[operaciones6 operaciones7 operaciones8 operaciones9 operaciones10];
barh(y,'FaceColor','flat')
yticklabels({'N° operaciones biseccion','N° operaciones regula Falsi','N° operaciones secante','N° operaciones punto fijo','N° operaciones Newton'})

figure(10)

y=[tFin6 tFin7 tFin8 tFin9 tFin10];
barh(y,'FaceColor','flat')
yticklabels({'Demora biseccion','Demora regula Falsi','Demora secante','Demora punto fijo','Demora Newton'})

pause(10)
% analizaremos f3()
% analisaremos entre los puntos -10 a 10 porque es donde se puede observar un
% cambio de signo en f3(x)
a=-10;
b=10;
tCom=tic;
[x11,error11,iteracion11,operaciones11]=biseccion(a,b,tol,f3);
tFin11=toc(tCom);
tCom=tic;
[x12,error12,iteracion12,operaciones12]=regulaFalsi(a,b,tol,f3);
tFin12=toc(tCom);
tCom=tic;
[x13,error13,iteracion13,operaciones13]=secante(a,b,tol,f3);
tFin13=toc(tCom);
tCom=tic;
[x14,error14,iteracion14,operaciones14]=puntoFijo(a,tol,f3,g3);
tFin14=toc(tCom);
tCom=tic;
[x15,error15,iteracion15,operaciones15]=newtonRp(a,tol,f3);
tFin15=toc(tCom);
figure(12)
hold on
title("Errores de los distintos metodos en x^3 - 7*x^2 +14*sin(2*pi*x)-6 ")
plot(error11)
plot(error12)
plot(error13)
plot(error14)
plot(error15)
legend(["Error metodo biseccion","Error metodo regula false", "Error metodo secante ", "Error metodo punto fijo","Error metodo Newton"],'location','northeast')
hold off
fprintf("Metodos , sus tiempos y cantidad de calculos f3(x)\n");
fprintf("Metodo de la biseccion\nN° de iteraciones:%i\nTiempo:%i\n",iteracion11,tFin11)
fprintf("Metodo regula falsi\nN° de iteraciones:%i\nTiempo:%i\n",iteracion12,tFin12)
fprintf("Metodo de la secante\nN° de iteraciones:%i\nTiempo:%i\n",iteracion13,tFin13)
fprintf("Metodo del punto fijo\nN° de iteraciones:%i\nTiempo:%i\n",iteracion14,tFin14)
fprintf("Metodo de Newton Raphson\nN° de iteraciones:%i\nTiempo:%i\n",iteracion15,tFin15)
%-----------------------------------------------------------------------------------------
figure(13)
hold on
title("Valores de x en los distintos metodos en 7*x^2 +14*sin(2*pi*x)-6 ")
plot(x11)
plot(x12)
plot(x13)
plot(x14)
plot(x15)
legend(["Valores x metodo biseccion","Valores x metodo regula false", "Valores x metodo secante ", "Valores x metodo punto fijo","Valores x metodo Newton"],'location','northeast')
hold off

figure(14)
y=[iteracion11 iteracion12 iteracion13 iteracion14 iteracion15];
barh(y)
yticklabels({'N° Iteracioes biseccion','N° Iteraciones regula Falsi','N° Iteraciones secante','N° Iteraciones punto fijo','N° Iteraciones Newton'})

figure(15)

y=[operaciones11 operaciones12 operaciones13 operaciones14 operaciones15];
barh(y,'FaceColor','flat')
yticklabels({'N° operaciones biseccion','N° operaciones regula Falsi','N° operaciones secante','N° operaciones punto fijo','N° operaciones Newton'})

figure(16)

y=[tFin11 tFin12 tFin13 tFin14 tFin5];
barh(y,'FaceColor','flat')
yticklabels({'Demora biseccion','Demora regula Falsi','Demora secante','Demora punto fijo','Demora Newton'})

pause(10)

%ver agina 82 memoria
