function[xsalida,error,iteracion,operaciones]=newtonRp(x0,tol,f)
syms x
xsalida=[];
error=[];
d=diff(f);
d=inline(d);
f=inline(f);
iteracion=0;
operaciones=0;
while abs(f(x0))>tol
    fx=f(x0);
    dx=d(x0);
    xi=x0 -(fx/dx);
    x0 = xi;  
    xsalida=[xsalida,xi];
    error=[error,f(xi)];
    iteracion=iteracion+1;
    operaciones=operaciones+2;
end
end