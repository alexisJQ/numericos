function [x1,error,iteracion,operaciones]=puntoFijo(a,tol,f,g)
    syms x;
    error=[];
    x1=[];
    gdiff=diff(g);
    gdiff=inline(gdiff);
    f=inline(f);
    g=inline(g);
    xi=g(a);
    error=[error,f(xi)];
    x1=[x1,xi];
    iteracion=1;
    operaciones=0;
    while (abs(f(xi))> tol) && (abs(gdiff(xi))< 1)  
        f(xi)
        a=xi;
        xi=g(a);
        error=[error,f(xi)];
        x1=[x1,xi];
        iteracion=iteracion+1
        operaciones=0;
    
    end
        
        
        
    


end