function [x,error,iteracion,operaciones]=regulaFalsi(a,b,tol,f)
    %Metodo de la falsa posicion
syms x
f=inline(f);
x=[];
xa= a;
xb= b;
error=[];
vc = (xa*f(xb)-xb*f(xa))/(f(xb)-f(xa));
error=[error,f(vc)];
x=[x,vc];
iteracion=1;
operaciones=5;
while (abs(f(vc)) >= tol)
    vc = (xa*f(xb)-xb*f(xa))/(f(xb)-f(xa));
    if ( f(xa)*f(vc) <0 )
        xb=vc;
    else
        xa=vc;
    end
    x=[x,vc];
    error = [error,f(vc)];
    iteracion = iteracion+1;
    operaciones=operaciones+5;
end

end