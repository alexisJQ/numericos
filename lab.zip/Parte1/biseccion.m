function [x,error,iteracion,operaciones]=biseccion(a,b,tol,f)
syms x;
f=inline(f);
x=[];
error=[];
m=(b-a)/2;
x=[x,m];
error=[error,f(m)];
iteracion=1;
operaciones=2;
while abs(f(m)) > tol
    m = a+(b-a)/2;
    if f(m)==0
        a=m;
        b=m;
    elseif sign(f(a))== sign(f(m))
        a=m;
    elseif sign(f(b))== sign(f(m))
        b=m;
    end
    x=[x,m];
    error=[error,f(m)];
    iteracion=iteracion+1;
    operaciones=operaciones+3;
end
    
end