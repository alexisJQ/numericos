function [x,error,iteracion,operaciones]=secante(a,b,tol,f)
 syms x;
 f=inline(f);
 error=[];
 x=[];
 xi=b-f(b)*(a-b)/(f(a)-f(b));
 error=[error,f(xi)] ;   
  x=[x,xi];
  a=b;
  b=xi;
  iteracion=1;
  operaciones=4;
 while abs(f(xi)) > tol
    xi=b-f(b)*(a-b)/(f(a)-f(b));
    a=b;
    b=xi;
    x=[x,xi];
    error=[error,f(xi)];
    iteracion=iteracion+1;
    operaciones=operaciones+4;
 end
 
end