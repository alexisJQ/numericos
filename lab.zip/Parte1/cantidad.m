
function [x] = cantidad(a,b,puntos)
dif = abs(b-a);
salto = dif / puntos;
x=a:salto:b;


end

