syms x
f2 = x - 2^(-x);
f3 = exp(-x)-x^2+ 3*x - 2
f= x^3 - 7*x^2 +14*sin(2*pi*x)-6
g = (x^3 - +14*sin(2*pi*x)-6)/7*x
g3= (x^2 - exp(-x) +2)/3
g2 = 2^(-x);
a=-10;
b=10;
tol=0.0001;
[x,error1]=biseccion(a,b,tol,f)
salida1=[x;error1];
hold on
 plot(error1')

[x,error2]=regulaFalsi(a,b,tol,f)

salida2=[x,error2];
 plot(error2')

[x,error3]=secante(a,b,tol,f);
salida3=[x;error3]
 plot(error3')

 [x,error4]=puntoFijo(a,tol,f,g);
 salida4=[x;error4];
  plot(error4')

[x,error5]=newtonRp(a,tol,f)
salida5=[x;error5];
  plot(error5')
salida6=[error1]
%plot(error1)
%plot(error2)
%salidaFinal=horzcat(2,error1,error2)
%plot(salidaFinal')