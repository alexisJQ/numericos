function [L,operaciones]=cholesky(A)
    [N,M]=size(A);
     L= zeros(N,M);
     operaciones=0;
    for i = 1 : N
        L(i,i) = sqrt(A(i,i));
        L(i+1:N,i) = A(i+1:N,i)/A(i,i);
        operaciones=operaciones+1+N;
        for j = i + 1 : N
            L(j:N,j) = A(j:N,j) - L(j,i)*L(j:N,i);
            operaciones=operaciones+N;
        end
    end
    
end
