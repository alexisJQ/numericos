function [w,x,operaciones] = LSQR (A,b,tol,limite)
[M,N]=size(A);
iteraciones=0;
operaciones=0;
B=norm(b);
u=b/B;
a=norm(A'*u);
v=(A'*u)/a;
w=v;
x=0;
fiLinea=B;
pLinea=a;
operaciones=4*N;
for i=1 : limite
    B=norm(A*v-a*u);
    u=(A*v-a*u)/B;
    a=norm((A'*u - B*v));
    v=(A'*u-B*v)/a;
%--------------------------------------%
    p=sqrt((pLinea^2)+(B^2));
    c=pLinea/p;
    s=B/p;
    theta=s*a;
    pLinea=-c*a;
    fi=c*fiLinea;
    fiLinea=s*fiLinea;
%--------------------------------------%
    x=x+(fi/p)*w;
    w=v-(theta/p)*w;
    operaciones=operaciones+4*N;
end

        
end