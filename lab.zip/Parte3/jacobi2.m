function [X,paso,x,errores,operaciones] = jacobi2 (A,b,tol)
iteraciones=0;
operaciones=0;
[M,N]=size(A);
errores=[];
 I=zeros(M,N);
 S=zeros(M,N);
 D=zeros(M,N);
for i = 1 :M
    for j=i+1:M
        if i~=j
           D(j,i)=0;
           D(i,j)=0;
           I(j,i)=A(j,i);
           I(i,j)=0;
           S(i,j)=A(i,j);
           S(j,i)=0;
           operaciones=operaciones+6;
        end
    end
    D(i,i)=A(i,i);
    I(i,i)=0;
    S(i,i)=0;        
    operaciones=operaciones+3;
end
fin=0;
paso=1;
x0=ones(N,1);
x(1,:)=x0';
while(fin==0) && (paso<=1000)
    for componente=1:N
        vectant=0;
        vectsig=0;
        for k=1:componente -1 
            vectant=vectant+A(componente,k)*x(paso,k);
            operaciones=operaciones+1;
        end
        for k=componente+1 : N
            vectsig=vectsig +A(componente,k)*x(paso,k);
            operaciones=operaciones+1;
        end
        x(paso+1,componente)=(b(componente)-vectant-vectsig)/A(componente,componente); 
        operaciones=operaciones+1;
        
    end
    e=norm(A*x(paso+1,:)'-b);
    errores=[errores,e];
    operaciones=operaciones+N;
    if (x(paso,:)== x(paso+1,:)) | (e<tol)
        fin=1;
        
        
    end
    paso=paso+1;
end
    X=x(paso,:);
end