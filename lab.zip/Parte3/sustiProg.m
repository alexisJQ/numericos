function [X] = sustiProg(A,b)
[N,M]=size(A);
X=zeros(N,1);
X(1,1)=b(1,1)/A(1,1);
for i=2 : N
    X(i,1) = (b(i,1)-sum(A(i,1:i-1)*X(1:i-1,1)))/A(i,i);


end    

end