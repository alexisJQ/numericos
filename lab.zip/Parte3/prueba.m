A = load('A289.dat');
b = load('b289.dat');
tol=0.000001;
%iterativos%
tCom=tic;
[solucionJ,iteracionesJ,solucionesJ,erroresJ,operacionesJ]=jacobi2(A,b,tol);
tFinJ=toc(tCom);
tCom=tic;
[solucionS,iteracionesS,solucionesS,erroresS,operacionesS]=seidel2(A,b,tol);
tFinS=toc(tCom);
figure(1)
hold on
title("Errores de los metodos jacobi y seidel")
plot(erroresJ)
plot(erroresS)
legend(["Jacobi","seidel"])
hold off

figure(2)
hold on
title("Valores de los X en metodo jacobi y seidel")
plot(solucionesJ)
plot(solucionesS)
legend(["Jacobi","seidel"])
hold off

figure(3)
xO=[operacionesJ operacionesS];

bar(xO,'FaceColor','flat')

xticklabels({' jacobi','seidel'})
title('N° de operaciones realizada en los metodos ');
xlabel('Metodos') 
ylabel('Operaciones')

figure(4)
xI=[iteracionesJ iteracionesS];

bar(xI,'FaceColor','flat')
xticklabels({' jacobi','seidel'})
title('N° de iteraciones realizada en los metodos ');
xlabel('Metodos') 
ylabel('Iteraciones')

figure(5)
xF=[tFinJ tFinS];

bar(xF,'FaceColor','flat')
xticklabels({' jacobi','seidel'})
title('Cantidad de tiempo qe lleva realizar los metodos ');
xlabel('Metodos') 
ylabel('Tiempo en segundos')

%Directos%
tCom=tic;
[L,U,operaciones1]= LUDoolitle (A);
tFin1=toc(tCom);
Z=sustiProg(L,b);
solucion1=sustiRegre(U,Z);
error1=norm(A*solucion1-b);

tCom=tic;
[T,operaciones2]=cholesky(A);
tFin2=toc(tCom);
Z2=sustiRegre(T',b);
solucion2=sustiProg(T,Z2);
error2=norm(A*solucion2-b);

tCom=tic; 
[Q,R,operaciones3]=QRGM(A);
tFin3=toc(tCom);
Y3=Q'*b;
solucion3=sustiRegre(R,Y3);
error3=norm(A*solucion3-b);

limite=1000;
tCom=tic;
[w4,X4,operaciones4] = LSQR (A,b,tol,limite);
error4=norm(A*X4-b);
tFin4=toc(tCom);

%errores grafica co cholesky
figure(6)

x1=[error1 error2 error3 error4];
 
bar(x1,'FaceColor','flat')
xticklabels({' LU',' Cholesky',' QR de Gram', 'LSRQ'})
title('Error de los metodos ');
xlabel('Metodos') 
ylabel('Error')
figure(7)
%errores grafca sin cholesky
x2=[error1 error3 error4];
bar(x2,'FaceColor','flat')
xticklabels({' LU',' QR de Gram','LSRQ'})
title('Errores De los metodos sin Cholesky');
xlabel('Metodos') 
ylabel('Error') 

figure(8)
%Grafica del tiempo todas las factorizaciones
x3=[tFin1 tFin2 tFin3 tFin4];
bar(x3,'FaceColor','flat')
title('Demora De los metodos');
xlabel('Metodos') 
ylabel('Tiempo en segundos') 

xticklabels({'LU ','Cholesky','QR','LSQR'})
%Grafica de cantidad e operaciones

figure(9)

x4=[operaciones1 operaciones2 operaciones3 operaciones4 ];
bar(x4,'FaceColor','flat')
title('Cantidad de operaciones de los metodos');
xlabel('Metodos') 
ylabel('cantidad') 

xticklabels({'LU','Cholesky','QR','LSQR'})


