function  [L,U,operaciones] = LUDoolitle (A)
    [M,N]=size(A);
    L=zeros (M);
    U=zeros(M);
    L(1,1)=1;
    U(1,1)=A(1,1);
    operaciones=0;
    for i=2 : M
        L(i,i)=1;
        U(1,i)=A(1,i);
        L(i,1)=A(i,1);
        L(i,1)=A(i,1)/U(1,1);
        operaciones=operaciones+4;
    end
    
    for j=2:M
        for i=j : M
            suma1=0;
            sumau=0;
            for k=1 :j-1
                if(U(k,i)~=0) && (L(j,k)~=0)
                    suma1=suma1+U(k,i)*L(j,k);
                    operaciones=operaciones+1;
                end
                if (U(k,j)~=0) && (L(i,k)~=0)&& (i~=j)
                    sumau=sumau+U(k,j)*L(i,k);
                    operaciones=operaciones+1;
                   
                end
            end
            U(j,i)=A(j,i)-suma1;
            operaciones=operaciones+1;
            if(j<M) && (i>j)
                L(i,j)=(A(i,j)-sumau)/U(j,j);
                operaciones=operaciones+1;
            end
        end
    end
end