function [Q,R,operaciones]=QRGM(A)
    [M,N]=size(A);
    Q=A;
    R=zeros(N);
    operaciones=0;
    for k=1 : N
        for i=1 :k-1
            R(i,k)=Q(:,i)'*Q(:,k);
            Q(:,k) = Q(:,k) -Q(:,i)*R(i,k);
            operaciones=operaciones+N;
        end
        R(k,k)=norm(Q(:,k));
        Q(:,k)=Q(:,k)/R(k,k);
        operaciones=operaciones+N;
    end
end