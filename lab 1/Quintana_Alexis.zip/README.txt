este laboratorio fue dividido en tres partes, los cuales estan guardados en sus respectivas
carpetas (carpeta 1, carpeta 2,carpeta 3), cada una de estas partes cuenta con un
archivo main, el cual al ser ejecutado, realizara todos los procesos que se realizaron para
dicha sección.